package com.example.eshopapi.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CategoryRequest(
    @NotBlank(message = "Tên danh mục không được để trống")
    @Size(max = 100, message = "Tên tối đa 100 ký tự")
    String name,

    @Size(max = 255, message = "Mô tả tối đa 255 ký tự")
    String description
) {}
